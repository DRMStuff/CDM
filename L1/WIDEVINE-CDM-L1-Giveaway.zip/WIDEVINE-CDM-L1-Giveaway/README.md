# WIDEVINE CDM L1 Giveaway
 widevine decryption module
# WARNING TO ALL VINETRIMMER USERS 
VINETRIMMER HAS CODE TO STOLE YOUR DEVICES I HAVE ACCESSED
THEIR VAULT AND HAVE HUNDREDS OF CDM STOLEN FROM YOU IDIOTS


*WvLEAKS* <wvleaks@proton.me> for working cdm

## Requirements

* [Python](https://python.org/) 3.9 or newer
* Python package dependencies
* Pywidevine

## Installation

1. Install the requirements above, place the binaries in your PATH.
2. Clone the GitHub repo or download a zip of it
3. Place cdm in right path & enjoy